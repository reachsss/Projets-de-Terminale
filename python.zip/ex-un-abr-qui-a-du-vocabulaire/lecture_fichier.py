def get_donnees(nom_de_fichier):
    with open(nom_de_fichier,'r', encoding ="UTF-8") as f:
        donnees = f.readlines()
    return donnees

def get_mots(phrase):
    phrase = phrase.strip('\n\r\t\'\".,;!?:«»-–—―§_()…*·  ')
    mots = phrase.split(' ')
    for i in range(len(mots)):
        mots[i] = mots[i].strip('\n\r\t\'\".,;!?:«»-–—―§_()…*·  ')
        mots[i]=mots[i].lower()
    i = 0
    while i < len(mots):
        if '’' in mots[i]:
            d = mots[i].split('’')
            mots.pop(i)
            mots.insert(i,d[1])
            mots.insert(i,d[0]+'’')
        i += 1
    i = 0
    while i < len(mots):
        if '\'' in mots[i]:
            d = mots[i].split('\'')
            mots.pop(i)
            mots.insert(i,d[1])
            mots.insert(i,d[0]+'\'')
        i += 1
    i = 0
    while i < len(mots):
        if '-' in mots[i]:
            d = mots[i].split('-')
            mots.pop(i)
            mots.insert(i,d[1])
            mots.insert(i,d[0])
        i += 1
    return mots