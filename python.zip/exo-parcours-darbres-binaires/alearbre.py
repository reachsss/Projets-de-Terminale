import p5, random



class Arbre:
    def __init__(self,valeur=None,fils_gauche=None,fils_droit=None):
        self.contenu=valeur
        self.fg=fils_gauche
        self.fd=fils_droit

    def dessine(self,largeur):
        '''Représente l'arbre graphiquement avec p5.'''
        self.__drec__(largeur/2,20,largeur/2)


    def __drec__(self,x,y,d):
        '''Méthode privée utilisée pour la représentation graphique'''
        if self.contenu==None:
            return
        p5.stroke(p5.color(0,0,0))
        p5.ellipse(x,y,28,22)
        p5.text(self.contenu,x-5*(len(str(self.contenu))//2+1),y+5)
        if self.fg:
            p5.stroke(p5.color('#26c21a'))
            p5.line(x-11,y+6,x-d/2,y+50)
            self.fg.__drec__(x-d/2,y+50,d/2)
        if self.fd:
            p5.stroke(p5.color('#624506'))
            p5.line(x+10,y+6,x+d/2,y+50)
            self.fd.__drec__(x+d/2,y+50,d/2)

    def ajoute_alea(self,valeur):
        ''' Ajoute la valeur dans l'arbre en avançant au hasard'''
        actuel=self
        if actuel.contenu==None:
            actuel.contenu=valeur
            return
        while True:
            if actuel.contenu==valeur:
                return
            tirage=random.random()
            if tirage<0.5:
                if actuel.fg:
                    actuel=actuel.fg
                else:
                    actuel.fg=Arbre(valeur)
                    return
            else:
                if actuel.fd:
                    actuel=actuel.fd
                else:
                    actuel.fd=Arbre(valeur)
                    return

    def aleArbre(taille):
        vmax=256
        while vmax<4*taille:
            vmax=2*vmax
        valeurs = random.sample(range(vmax), taille)
        arbre = Arbre()
        for v in valeurs:
            arbre.ajoute_alea(v)
        return arbre

    def parcours_lg(self):
        ''' Renvoie le parcours en largeur sous forme d'une liste.'''
        fa=[self]
        parcours=[]
        while not fa==[]:
            noeud=fa.pop(0)
            parcours.append(noeud.contenu)
            if noeud.fg:
                fa.append(noeud.fg)
            if noeud.fd:
                fa.append(noeud.fd)
        return parcours

    def parcours_prefixe(self, parcours = None):
        '''Renvoie le parcours préfixe sous forme d'une liste.'''
        if parcours is None:
            parcours = []
        if self.contenu is not None:
            parcours.append(self.contenu)
            if self.fg is not None:
                self.fg.parcours_prefixe(parcours)
            if self.fd is not None:
                self.fd.parcours_prefixe(parcours)
        return parcours

    def parcours_infixe(self, parcours = None):
        '''Renvoie le parcours infixe sous forme d'une liste.'''
        if parcours is None:
            parcours = []
        if self.contenu is not None:
            if self.fg is not None:
                self.fg.parcours_infixe(parcours)
            parcours.append(self.contenu)
            if self.fd is not None:
                self.fd.parcours_infixe(parcours)
        return parcours

    def parcours_suffixe(self, parcours = None):
        '''Renvoie le parcours suffixe sous forme d'une liste.'''
        if parcours is None:
            parcours = []
        if self.contenu is not None:
            if self.fg is not None:
                self.fg.parcours_suffixe(parcours)
            if self.fd is not None:
                self.fd.parcours_suffixe(parcours)
            parcours.append(self.contenu)
        return parcours




