# exécuter cette cellule pour préparer votre environnement
import p5
import math
import random
import __main__


def generer_trajet():
    # km parcourus : 2 à 25 km
    km = round(random.uniform(2, 25), 1)

    # durée : vitesse moyenne 18 à 35 km/h
    vitesse_moy = random.uniform(18, 35)
    duree = int((km / vitesse_moy) * 3600)

    # vitesse max réaliste en ville : 40 à 70 km/h
    vitesse_max = random.randint(40, 70)

    # consommation : 5.5 à 10 L/100 en ville -> litres consommés
    conso_100 = random.uniform(5.5, 10)
    consommation = round(km * conso_100 / 100, 2)

    return {
        "nombre_km": km,
        "duree": duree,
        "vitesse_max": vitesse_max,
        "consommation": consommation
    }
def interroge_ordinateur_de_bord():
    # Génération de 50 trajets
    trajets = [  {'consommation': 0.2, 'duree': 235, 'nombre_km': 2.2, 'vitesse_max': 70},
                 {'consommation': 0.57, 'duree': 878, 'nombre_km': 8.0, 'vitesse_max': 40},
                 {'consommation': 0.93, 'duree': 2166, 'nombre_km': 16.1, 'vitesse_max': 58},
                 {'consommation': 0.56, 'duree': 1004, 'nombre_km': 8.7, 'vitesse_max': 53},
                 {'consommation': 0.37, 'duree': 634, 'nombre_km': 5.2, 'vitesse_max': 56},
                 {'consommation': 0.85, 'duree': 2219, 'nombre_km': 13.5, 'vitesse_max': 49},
                 {'consommation': 1.79, 'duree': 2998, 'nombre_km': 21.0, 'vitesse_max': 70},
                 {'consommation': 1.49, 'duree': 1652, 'nombre_km': 15.4, 'vitesse_max': 43},
                 {'consommation': 1.79, 'duree': 3706, 'nombre_km': 20.5, 'vitesse_max': 55},
                 {'consommation': 1.78, 'duree': 2286, 'nombre_km': 18.1, 'vitesse_max': 70},
                 {'consommation': 0.66, 'duree': 1891, 'nombre_km': 10.8, 'vitesse_max': 55},
                 {'consommation': 0.18, 'duree': 380, 'nombre_km': 3.3, 'vitesse_max': 68},
                 {'consommation': 1.74, 'duree': 2387, 'nombre_km': 21.9, 'vitesse_max': 49},
                 {'consommation': 0.75, 'duree': 1029, 'nombre_km': 8.5, 'vitesse_max': 41},
                 {'consommation': 0.91, 'duree': 2021, 'nombre_km': 13.3, 'vitesse_max': 40},
                 {'consommation': 0.49, 'duree': 1206, 'nombre_km': 6.2, 'vitesse_max': 66},
                 {'consommation': 1.09, 'duree': 2103, 'nombre_km': 15.1, 'vitesse_max': 67},
                 {'consommation': 1.35, 'duree': 2199, 'nombre_km': 16.6, 'vitesse_max': 57},
                 {'consommation': 0.72, 'duree': 1329, 'nombre_km': 9.4, 'vitesse_max': 68},
                 {'consommation': 0.34, 'duree': 716, 'nombre_km': 5.9, 'vitesse_max': 54},
                 {'consommation': 0.26, 'duree': 587, 'nombre_km': 3.5, 'vitesse_max': 63},
                 {'consommation': 1.53, 'duree': 2400, 'nombre_km': 21.6, 'vitesse_max': 48},
                 {'consommation': 0.93, 'duree': 1374, 'nombre_km': 11.7, 'vitesse_max': 43},
                 {'consommation': 0.18, 'duree': 327, 'nombre_km': 3.0, 'vitesse_max': 46},
                 {'consommation': 1.22, 'duree': 2576, 'nombre_km': 13.7, 'vitesse_max': 58},
                 {'consommation': 1.27, 'duree': 2593, 'nombre_km': 20.9, 'vitesse_max': 55},
                 {'consommation': 1.0, 'duree': 1693, 'nombre_km': 10.7, 'vitesse_max': 56},
                 {'consommation': 2.43, 'duree': 2573, 'nombre_km': 24.4, 'vitesse_max': 49},
                 {'consommation': 1.3, 'duree': 2294, 'nombre_km': 14.0, 'vitesse_max': 41},
                 {'consommation': 1.42, 'duree': 2549, 'nombre_km': 21.2, 'vitesse_max': 50},
                 {'consommation': 1.76, 'duree': 3792, 'nombre_km': 23.0, 'vitesse_max': 62},
                 {'consommation': 0.89, 'duree': 1434, 'nombre_km': 11.5, 'vitesse_max': 54},
                 {'consommation': 0.58, 'duree': 1697, 'nombre_km': 9.7, 'vitesse_max': 40},
                 {'consommation': 1.27, 'duree': 2553, 'nombre_km': 14.5, 'vitesse_max': 55},
                 {'consommation': 1.48, 'duree': 2091, 'nombre_km': 17.2, 'vitesse_max': 70},
                 {'consommation': 1.47, 'duree': 2536, 'nombre_km': 18.4, 'vitesse_max': 64},
                 {'consommation': 2.34, 'duree': 2623, 'nombre_km': 23.6, 'vitesse_max': 45},
                 {'consommation': 0.22, 'duree': 241, 'nombre_km': 2.3, 'vitesse_max': 41},
                 {'consommation': 0.26, 'duree': 722, 'nombre_km': 4.6, 'vitesse_max': 53},
                 {'consommation': 1.17, 'duree': 3509, 'nombre_km': 18.1, 'vitesse_max': 67},
                 {'consommation': 0.48, 'duree': 703, 'nombre_km': 5.2, 'vitesse_max': 59},
                 {'consommation': 1.34, 'duree': 3164, 'nombre_km': 20.4, 'vitesse_max': 64},
                 {'consommation': 1.15, 'duree': 1353, 'nombre_km': 12.0, 'vitesse_max': 46},
                 {'consommation': 0.42, 'duree': 472, 'nombre_km': 4.2, 'vitesse_max': 42},
                 {'consommation': 0.41, 'duree': 646, 'nombre_km': 5.3, 'vitesse_max': 69},
                 {'consommation': 0.75, 'duree': 1823, 'nombre_km': 12.6, 'vitesse_max': 47},
                 {'consommation': 0.28, 'duree': 518, 'nombre_km': 4.9, 'vitesse_max': 56},
                 {'consommation': 1.75, 'duree': 4224, 'nombre_km': 23.2, 'vitesse_max': 54},
                 {'consommation': 0.96, 'duree': 1531, 'nombre_km': 14.3, 'vitesse_max': 45},
                 {'consommation': 0.87, 'duree': 1530, 'nombre_km': 11.4, 'vitesse_max': 48}]
    return trajets
    
def moyenne_glissante(tableau,valeur):
    ########
    pass
    ##########
    return tableau,valeur
    


class Simulateur_tableau_de_bord():
    def __init__(self):
        self.fps=30
        self.debug=False
        self.tab=[]
        p5.run(self.setup, self.draw)
        
    def setup(self):
        self.fond = p5.loadImage("https://capytale2.ac-paris.fr/web/sites/default/files/2025/11-27/12-16-48/compteur.png")
        p5.frameRate(self.fps)
        p5.createCanvas(600, 250)
        p5.strokeWeight(6)
        p5.stroke(242, 104, 13)
        p5.textSize(20)
        p5.fill("black")

    def draw(self):
        # construction de l'image
        p5.background("white")
        p5.background(self.fond)
        v,rpm = self.vitesse_instantanee_compte_tours()
        # vitesse
        v=v*3600/1000
        self.tab,v=__main__.moyenne_glissante(self.tab,v)
        angle=-209 + v/200*236
        r=100
        x0=298
        y0=139
        x1=x0+r*math.cos(angle/180*math.pi)
        y1=y0+r*math.sin(angle/180*math.pi)
        p5.line(x0, y0, x1, y1)
        if self.debug==True:
            p5.text(str(int(round(v,0))),5,20)
        # rpm
        
        angle=rpm/8000*152 -212 # -209 + rpm/200*236
        r=100
        x0=118
        y0=138
        x1=x0+r*math.cos(angle/180*math.pi )
        y1=y0+r*math.sin(angle/180*math.pi)
        p5.line(x0, y0, x1, y1)
        if self.debug==True:
            p5.text(str(int(round(rpm,0))),5,40)
        

    def vitesse_instantanee_compte_tours(self) -> float:
        """
        Simule la vitesse instantanée (m/s) d'une voiture + compte-tours.
        """

        # --- VITESSE (inchangée) ---
        if not hasattr(self, "vitesse_actuelle"):
            self.vitesse_actuelle = 0.0

        t = p5.frameCount / self.fps
        self.vitesse_max = 30

        cycle1 = math.sin(t * 0.2)
        cycle2 = math.sin(t * 0.7)
        cycle3 = math.sin(t * 1.5)
        cycle = 0.6*cycle1 + 0.3*cycle2 + 0.1*cycle3

        vitesse_cible = self.vitesse_max/2 + self.vitesse_max/2 * cycle
        vitesse_cible = max(0.0, min(self.vitesse_max, vitesse_cible))

        inertie = 0.9
        self.vitesse_actuelle = inertie*self.vitesse_actuelle + (1-inertie)*vitesse_cible

        bruit = random.uniform(-1, 1)
        vitesse = self.vitesse_actuelle + bruit

        # --- COMPTE-TOURS --- #

        # Ratios
        rapports = [3.2, 2.1, 1.4, 1.0, 0.8]
        seuils = [6, 12, 18, 25]

        # Mémorisation du rapport précédent
        if not hasattr(self, "rapport_actuel"):
            self.rapport_actuel = 0

        rapport_nouveau = 0
        for i, s in enumerate(seuils):
            if vitesse > s:
                rapport_nouveau = i + 1

        ratio = rapports[rapport_nouveau]

        # Calcul brut du rpm cible
        rpm_cible = vitesse * ratio* 60 * 2

        # Clamp initial
        rpm_cible = max(700, min(6500, rpm_cible))

        # Initialisation du rpm lissé
        if not hasattr(self, "rpm"):
            self.rpm = rpm_cible

        # CHUTE AU CHANGEMENT DE RAPPORT
        if rapport_nouveau != self.rapport_actuel:
            self.rpm -= 1500     # chute visible
            self.rpm = max(700, self.rpm)
            self.rapport_actuel = rapport_nouveau

        # Lissage vers la valeur réelle
        inertie_rpm = 0.9
        self.rpm = inertie_rpm*self.rpm + (1 - inertie_rpm)*rpm_cible

        # Bruit moteur
        #self.rpm += random.uniform(-80, 80)

        # Clamp final (sécurité)
        self.rpm = max(700, min(6500, self.rpm))

        return max(0.0, vitesse), self.rpm
    
