import p5

def dessine(arbre,largeur):
        drec(arbre, largeur/2,20,largeur/2)


def drec(arbre,x,y,d):
    if arbre.contenu is None:
        return
    p5.ellipse(x,y,28,22)
    p5.text(arbre.contenu,x-5*(len(str(arbre.contenu))//2+1),y+5)
    if arbre.fils_gauche:
        p5.line(x-11,y+6,x-d/2,y+50)
        drec(arbre.fils_gauche,x-d/2,y+50,d/2)
    if arbre.fils_droit:
        p5.line(x+10,y+6,x+d/2,y+50)
        drec(arbre.fils_droit,x+d/2,y+50,d/2)
