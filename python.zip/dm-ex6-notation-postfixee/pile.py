'''Le module pile permet une implémentation d'un structure de pile basée sur les opérations suivantes :
    pile_vide : renvoie une pile vide
    empiler : empile une valeur donnée dans la pile_vide
    depiler : dépile et renvoie une valeur de la pile_vide
    est_vide : indique si la pile est vide
'''

def creer_pile():
    '''
    objectif : créer une pile vide
    paramètres : Aucun
    retour : pile vide
    '''
    return []

def empiler(pile, valeur):
    '''
    objectif : empiler une valeur dans la pile
    paramètres : une pile, une valeur (peu importe le type)
    retour : Rien
    '''
    pile.append(valeur)


def depiler(pile):
    '''
    objectif : dépiler une valeur de la pile
    paramètres : une pile
    retour : l'élément dépilé
    '''
    if est_vide(pile):
        return None
    return pile.pop()

def est_vide(pile):
    '''
    objectif : détermine si une pile vide
    paramètres : une pile
    retour : booléen, True si la pile est vide, False sinon
    '''
    return len(pile)==0

def taille_pile(p):
    return len(p)
    
   
def test():
    p=creer_pile()
    est_vide(p)
    p
    empiler(p,3)
    empiler(p,1)
    empiler(p,4)
    empiler(p,1)
    empiler(p,6)
    p
    depiler(p)
    empiler(p,5)
    empiler(p,9)
    print(p)
    print(taille_pile(p))
    

